import torch
import random
import numpy as np
from collections import deque
from game import SnakeGameAI, Direction, Point
from model import Linear_QNet, QTrainer
from helper import plot


MAX_MEMORY = 100_000    # Maximaler Speicherplatz des deque
BATCH_SIZE = 1000       # Anzahl an Werten, die an das neuronale Netz übergeben werden
LR = 0.001              # Learning Rate

class Agent:

    def __init__(self):
        self.n_games = 0                        # Anzahl der Spiele, am Anfang 0
        self.epsilon = 0                        # randomness
        self.gamma = 0.9                        # discount rate
        self.memory = deque(maxlen=MAX_MEMORY)  # maximale Länge des Speichers festlegen
        self.model = Linear_QNet(11, 256, 3)    # Input Size, Hidden Size und Output Size definieren
        self.trainer = QTrainer(self.model, lr=LR, gamma=self.gamma)    # Model, Learning Rate und die Discout Rate übergeben


    def get_state(self, game):  # Zustand der Snake in der Umgebung erhalten
        head = game.snake[0]    # Kopfposition der Snake in einem Tuples abspeichern

        # Eckpunkte des Kopfes abspeichern
        point_l = Point(head.x - 20, head.y)    # Links
        point_r = Point(head.x + 20, head.y)    # Rechts
        point_u = Point(head.x, head.y - 20)    # Oben
        point_d = Point(head.x, head.y + 20)    # Unten
        
        dir_l = game.direction == Direction.LEFT    # die Richtungen des Direction Enum abspeichern
        dir_r = game.direction == Direction.RIGHT
        dir_u = game.direction == Direction.UP
        dir_d = game.direction == Direction.DOWN

        state = [   # Zustand wird in ein Array gespeichert, 11 Werte
                    # boolean value, entweder 0 oder 1
            # Gefahr vorne  1x
            (dir_r and game.is_collision(point_r)) or 
            (dir_l and game.is_collision(point_l)) or 
            (dir_u and game.is_collision(point_u)) or 
            (dir_d and game.is_collision(point_d)),

            # Gefahr rechts 1x
            (dir_u and game.is_collision(point_r)) or 
            (dir_d and game.is_collision(point_l)) or 
            (dir_l and game.is_collision(point_u)) or 
            (dir_r and game.is_collision(point_d)),

            # Gefahr links 1x
            (dir_d and game.is_collision(point_r)) or
            (dir_u and game.is_collision(point_l)) or
            (dir_r and game.is_collision(point_u)) or
            (dir_l and game.is_collision(point_d)),

            # Richtung 4x
            dir_l,      # nur 1 Wert kann 1 sein
            dir_r,
            dir_u,
            dir_d,

            # Standort des Apfels 4x    # Max. 2 Werte können 1 sein
            game.food.x < game.head.x,  # Apfel links
            game.food.x > game.head.x,  # Apfel rechts
            game.food.y < game.head.y,  # Apfel oben
            game.food.y > game.head.y   # Apfel unten
            ]

        return np.array(state, dtype=int)   # Rückgabe des Arrays

    def remember(self, state, action, reward, next_state, done):        # State, action, reward, nächster Zustand und game over
        self.memory.append((state, action, reward, next_state, done))   # Übergebene Werte in das memory Deque speichern, jedoch nur als 1 Element (tuple)
                                                                        # falls Memory_Max erreicht wird-> von links entfernen (deque wird von links nach rechts initialisiert)

    def train_long_memory(self):           #Langzeit gedächtnis trainieren
        if len(self.memory) > BATCH_SIZE:                           # Wenn das Deque memory größer ist als der Parameter Batch_size
            mini_sample = random.sample(self.memory, BATCH_SIZE)    # random.sample gibt eine gewisse Anzahl an zufälligen Inhalten aus dem Memory in einer Liste zurück
        else:
            mini_sample = self.memory                               # Inhalt von Memory in die Liste mini_sample speichern

        states, actions, rewards, next_states, dones = zip(*mini_sample)        # die Funktion zip koppelt die erste Position des Tuple mit der Variable states, die zweite Position mit der Variable actions usw.
        # alle state werden miteinander gekoppelt, alle action, reward etc. Somit hat die KI z.B. 1000 reward Ergebnisse in dem Parameter rewards
        self.trainer.train_step(states, actions, rewards, next_states, dones)   # Optimierungsfunktion aufrufen

    def train_short_memory(self, state, action, reward, next_state, done):  # Kurzzeitgedächntis
        self.trainer.train_step(state, action, reward, next_state, done)    # Optimierungsfunktion aufrufen
        # Parameter: Aktueller Zustand der Snake in der Umgebung, nächste Richtung, aktuelle Belohnung, nächster Zustand der Snake in der Umgebung und ob das Spiel vorbei ist


    def get_action(self, state):    # nächste Richtung berechnen/anfordern
        # random moves: tradeoff exploration / exploitation, am Anfang mehr Random moves, später weniger bis keine
        self.epsilon = 80 - self.n_games            # Epsilon = 80 - Anzahl an Spiele, kann negativ werden
        final_move = [0,0,0]                        # noch keine Richtung festgelegt, [gerade, rechts, links]
        if random.randint(0, 200) < self.epsilon:   # Zufällige Zahl zwischen 0 und 200, wenn diese kleiner ist als Epsilon
            move = random.randint(0, 2)             # Zufällige Zahl zwischen 0 und 2, entweder 0, 1 oder 2, Bestimmt die nächste Bewegungsrichtung
            final_move[move] = 1                    # Index der zufälligen Zahl auf 1 setzten
        else:
            state0 = torch.tensor(state, dtype=torch.float) # Array state in Tensor (multidimensionales Array) speichern
            prediction = self.model(state0)                 # state0 dem neuronalen Netz einspeisen
            move = torch.argmax(prediction).item()          # gibt den Index des größten Wert zurück, .item() gibt den Wert eines Tensors in standard Python Nummern zurück
            final_move[move] = 1                            # Richtung festlegen, vom Netz berechnet

        return final_move   # nächste Bewegungsrichtung der Snake

def clear_files():  # leert alle Textfiles
    file = open("head_x.txt", "w")  # Textfile wird geöffnet, w -> überschreiben aktiviert,
    file.close()                    # es wird nichts geschrieben, Textfile wird geschlossen
                                    # Textfile ist nun leer
    file = open("head_y.txt", "w")
    file.close()

    file = open("apfel_x.txt", "w")
    file.close()

    file = open("apfel_y.txt", "w")
    file.close()

    file = open("steps.txt", "w")
    file.close()

    file = open("score.txt", "w")
    file.close()

def score_zu_datei(score):   # Score in Textdatei abspeichern

    file = open("score.txt", "a")       # Erstellen/öffnen einer Textdatei, "a" = append (hinzufügen)
    file.write(str(int(score)) + "\n")  # Den Score in die Datei schreiben und in die nächste Zeile wechseln
    file.close()                        # Datei schließen


def kopf_zu_datei(head_x,head_y):       # Kopfposition Abspeichern

    # X Position des Kopfes in eine Textdatei schreiben.
    file = open("head_x.txt", "a")                  # Erstellen/öffnen einer Textdatei, "a" = append (hinzufügen)
    file.write(str(int(head_x)) + "\n")             # die X-Koordinate der Kopfposition der Snake in die Datei schreiben und in die nächste Zeile wechseln
    file.close()                                    # die Datei wieder schließen

    # Y Position des Kopfes in eine Textdatei schreiben
    file = open("head_y.txt", "a")
    file.write(str(int(head_y)) + "\n")
    file.close()

def schritte_zu_datei(steps):           # Schritte der Snake abspeichern

    file = open("steps.txt", "a")           # Erstellen/öffnen einer Textdatei, "a" = append (hinzufügen)
    file.write(str(int(steps)) + "\n")      # Anzahl der Schritte in die Datei schreiben und in die nächste Zeile wechseln
    file.close()                            # die Datei wieder schließen

def train():

    clear_files()               # alte Textdateien leeren
    plot_scores = []            # Liste beinhaltet alle Scores, benötigt für Diagramm
    plot_mean_scores = []       # Liste beinhaltet durchschnittliche Scores
    plot_steps = []             # Liste beinhaltet die Anzahl der Schritte pro Snake

    record = 0                  # Rekord auf 0 zurücksetzten
    steps = 0                   # Hilfsvariable für das Erfassen der Schrittanzahl
    durchschn_score = 0         # Hilfsvariable für den durchschnittlichen Score
    klein_durchschn_score = 0   # Hilfvariable für den durchschn. Score am Anfang

    agent = Agent()             # Referenz zur Klasse "Agent"
    game = SnakeGameAI()        # Referenz zur Klasse "SnakeGameAI"

    while True: # Dauerschleife, bis das Programm beendet wird

        # get old state
        state_old = agent.get_state(game)           #aktueller Zustand der Snake in Variable zwischenspeichern

        # get move
        final_move = agent.get_action(state_old)    # Mithilfe der "get_action" Methode die nächste Richtung der Snake anfordern und zwischenspeichern

        steps += 1                                  # Es wird ein schritt gemacht, Hilfsvariable für Schrittanzahl erhöhen

        # perform move and get new state
        reward, done, score = game.play_step(final_move)    # Schritt mithilfe der "play_step" Methode ausführen und Rückgabewerte zwischenspeichern
        state_new = agent.get_state(game)                   # nächste Richtung de Snake anfordern

        # train short memory
        agent.train_short_memory(state_old, final_move, reward, state_new, done)    # Hyperparameter mithilfe der train_short_memory optimieren

        # remember
        agent.remember(state_old, final_move, reward, state_new, done)  # Werte im Memory abspeichern

        head_x = 0                  #fixt einen Bug, fail to allocate Bitmap Meldung nach ca. 30 Spielen -> Programm stürzt ab
        head_y = 0
        head_x = game.snake[0].x    # Kopfposition zwischenspeichern
        head_y = game.snake[0].y

        kopf_zu_datei(head_x,head_y) #zwischengespeicherte Kopfposition übergeben und in Textdatei abspeichern

        if done:    # Snake ist gestorben
            # train long memory, plot result
            game.reset()        # Spiel zurücksetzten
            agent.n_games += 1  # Anzahl der Spiele um 1 erhöhen

            agent.train_long_memory()   # Langzeitgedächtnis, Hyperparameter mithilfe der Methode train_long_memory optimieren

            if score > record:      # überprüfen, ob es einen neuen Rekord gibt
                record = score      # wenn ja, neuen Rekord setzten
                agent.model.save()  # aktuelles Modell abspeichern

            score_zu_datei(score)   # Punktestand abspeichern

            schritte_zu_datei(steps)# Schritte in Textfile abspeichern

            # Durchschnittliche Schritte pro Apfel berechnen
            if (score == 0):                # Wenn score = 0
                steps_plot = steps          # Nur 1 Apfel gesamt
            else:
                steps_plot = steps/score   # Schritte durch Punktestand

            steps = 0  # Schritte zurücksetzten

            print('Game', agent.n_games, 'Score', score, 'Record:', record)
            # Finaler Score und Rekord als Text ausgeben

            if agent.n_games > 140:                                 # Wenn über 140 Spiele, neuer durschnittlicher Score
                durchschn_score += score
                mean_score = durchschn_score / (agent.n_games-139)  # Durchschn. Score
            else:                                                   # vorher
                klein_durchschn_score += score
                mean_score = klein_durchschn_score / (agent.n_games)# Gesamte Scoreanzahl durch Anzahl an Spielen = durchscnittlicher Score

            plot_steps.append(steps_plot)       # durchschnittliche Anzahl an Schritte der Liste hinzufügen
            plot_scores.append(score)           # der aktuelle Score wird der Liste hinzugefügt
            plot_mean_scores.append(mean_score) # Durchschnittlicher Score wird der Liste hinzugefügt

            plot(plot_scores, plot_mean_scores, plot_steps) # alle Listen werden in Diagrammen dargestellt


if __name__ == '__main__':  # main = top-level code, Startpunkt des Programms
    train()                 # Train() Funktion aufrufen