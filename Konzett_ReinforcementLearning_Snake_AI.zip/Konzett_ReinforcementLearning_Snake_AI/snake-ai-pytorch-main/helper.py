import matplotlib.pyplot as plt
from IPython import display

plt.ion()   # interaktiver Mode aktivieren

def plot(scores, mean_scores, plot_steps):  # Diagramm erstellen

    display.clear_output(wait=True)     # löscht den Ausgang der aktuellen Zelle?
    display.display(plt.gcf())          # dynamische aktualisierung des Diagramms
    plt.clf()                           # liefert das akutelle Diagramm

    plt.figure(1, figsize=(6.4, 4.8))   # größe der Grafik, in Inches

    plt.subplot(211)                    # 2 Diagramme, 1 Reihe, 1 Spalte
    plt.ylabel('Erzielter Punktestand') # beschriftung der Y-Achse
    plt.plot(scores, color='blue', label='data')                        # Diagramm des Punkestands erstellen
    plt.text(len(scores)-1, mean_scores[-1], str(mean_scores[-1]))      # Beschriftung der Linie
    plt.plot(mean_scores, color='limegreen',label='data')               # Diagramm des durchschnittlichen Punkestands erstellen
    plt.text(len(mean_scores)-1, mean_scores[-1], str(mean_scores[-1])) # Beschriftung der Linie

    plt.subplot(212)                    # 2 Diagramme, 1 Reihe, 2 Spalte
    plt.ylabel('durchsch. Schritte pro Apfel')                          # Beschriftung der Y-Achse
    plt.plot(plot_steps, color='red', label='data')                     # Diagramm der durchschnittlichen Schritte pro Apfel erstellen
    plt.text(len(plot_steps)-1, plot_steps[-1], str(plot_steps[-1]))    # Beschriftung der Linie
    plt.xlabel('Number of Games')       # beschriftung der X-Achse


    plt.show(block=False)   # Diagramm anzeigen
    plt.pause(.1)           # delay von 0.1 Sekunde