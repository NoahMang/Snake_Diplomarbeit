import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import os

class Linear_QNet(nn.Module):
    def __init__(self, input_size, hidden_size, output_size): # Eingangsgröße, versteckte Größe und Ausgangsgröße (neuronen)
        super().__init__()                                    # super() gibt Zugang zu den Methoden in der "superclass" ,

        # Die linearen Schichten des Neuronalen Netzes erstellen
        self.linear1 = nn.Linear(input_size, hidden_size)   # Eingangsgröße ist die input Size und die Ausgangsgröße ist die hidden Size
        self.linear2 = nn.Linear(hidden_size, output_size)  # Eingangsgröße ist die hidden Size und die Ausgangsgröße die output Size

    def forward(self, x):               # Erstellen eines feed forward neural Net
        x = F.relu(self.linear1(x))     # Die Relu Aktivierungsfunktion wird bei der Eingangsschicht angewendet
        x = self.linear2(x)             # In den hidden Layers sollte die Aktivierungsfunktion nicht angewendet werden
        return x                        # Rohe Nummern werden zurückgegeben

    def save(self, file_name='model.pth'):                      # abspeichern des Modells, Name der Datei wird übergeben
        model_folder_path = './model'
        if not os.path.exists(model_folder_path):               # Wenn es den Pfad noch nicht gibt
            os.makedirs(model_folder_path)                      # Neuen Pfad erstellen

        file_name = os.path.join(model_folder_path, file_name)  # Dateiname und Pfad abspeichern
        torch.save(self.state_dict(), file_name)                # Alle für die KI wichtigen Parameter abspeichern


class QTrainer: # Training und Optimisierung
    def __init__(self, model, lr, gamma):   # Die übergebenen Werte abspeichern
        self.lr = lr                        # Learning Rate
        self.gamma = gamma                  # Discount Rate
        self.model = model                  # Größe des neuronalen Netzes
        self.optimizer = optim.Adam(model.parameters(), lr=self.lr) # Parameter mithilfe eines Optimizer verbessern
        self.criterion = nn.MSELoss()                               # loss function, ist die mittlere quadratische Abweichung (mean squared error )

    def train_step(self, state, action, reward, next_state, done):  # Parameter sind entweder ein Tupil, eine Liste oder einzelne Werte
        state = torch.tensor(state, dtype=torch.float)
        next_state = torch.tensor(next_state, dtype=torch.float)    # Tensor ist ein mehrdimensionales Array
        action = torch.tensor(action, dtype=torch.long)             # Übergebene Werte als Float abspeichern
        reward = torch.tensor(reward, dtype=torch.float)
        # (n, x) ; wenn die Parameter meherere Werte beinhalten, hat es diese Form

        if len(state.shape) == 1:   # übergebener Wert ist nur Eindimensional
            # (1, x) , gewünschte Form; 1 Zeile; x Werte
            state = torch.unsqueeze(state, 0)           # gibt einen neuen Tensor mit der Dimension (1,x) zurück
            next_state = torch.unsqueeze(next_state, 0)
            action = torch.unsqueeze(action, 0)
            reward = torch.unsqueeze(reward, 0)
            done = (done, ) # tupil definieren

        # Vorhergesagtes Q-Value im aktuellen Zustand
        pred = self.model(state)        # dem neuronalen Netz den aktuellen Zustand übergeben und das Ergebnis zwischenspeichern

        # Neues Q-Value berechnen
        target = pred.clone()           # eine exakte Kopie erstellen
        for idx in range(len(done)):    # alle tensors haben die gleiche Länge
            Q_new = reward[idx]         # neues Q-Value entspricht der Belohnung
            if not done[idx]:           # wenn das Spiel noch nicht vorbei ist
                Q_new = reward[idx] + self.gamma * torch.max(self.model(next_state[idx]))   # neues Q-Value berechnen, vereinfachte Bellman equation

            target[idx][torch.argmax(action[idx]).item()] = Q_new   # setzt den maximalen Wert der action (3 versch. Werte) dem neuen Q-Value gleich


        self.optimizer.zero_grad()              # Gradient auf 0 setzten, da in PyTorch diese standardmäßig addiert werden
        loss = self.criterion(target, pred)     # loss Funktion berechnen
        loss.backward()                         # aktualiesiert den Gradienten

        self.optimizer.step()   # aktualisiert die Parameter



