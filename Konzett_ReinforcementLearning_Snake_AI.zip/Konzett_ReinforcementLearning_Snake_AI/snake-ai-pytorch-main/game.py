import pygame
import random
from enum import Enum
from collections import namedtuple
import numpy as np

pygame.init()   # PyGame initialisieren
font = pygame.font.Font('arial.ttf', 25)    # Schriftart und größe einstellen

class Direction(Enum):  # Enum ist ein Datentyp,
    RIGHT = 1
    LEFT = 2
    UP = 3
    DOWN = 4

Point = namedtuple('Point', 'x, y') # namedtuple benutzen, um den Code lesbarer zu machen.
# im Point können eine X und Y koordinate gespeichert werden. Ist Immutable, die Values X, Y können nicht verändert werden.

# rgb colors    # Farbsatz
WHITE = (255, 255, 255) # Schriftfarbe
RED = (200,0,0)         # Farbe des Apfels
BLUE1 = (0, 0, 255)     # Farbe der Snake
BLUE2 = (0, 100, 255)   # Farbe der Snake
BLACK = (0,0,0)         # Hintergrundfarbe
GREEN1 = (53, 135, 164) # Farbe des Kopfes der Snake
GREEN2 = (46, 209, 181) # Farbe des Kopfes der Snake

BLOCK_SIZE = 20 # größe der einzelnen Rechtecke
SPEED = 50  # Geschwindigkeit der Snake

class SnakeGameAI:

    def __init__(self, w=640, h=480):   # initialisierung notwendiger Parameter / Objekte
                                        # wird ausgeführt, sobald die Klasse initialisiert wird

        # der Parameter self wird verwendet, um die Variablen der Klasse zu erreichen
        self.w = w  # die Breite der grafischen Oberfläche
        self.h = h  # die Höhe der grafischen Oberfläche

        # init display
        self.display = pygame.display.set_mode((self.w, self.h))    #Grafische Oberfläche wird erstellt
        pygame.display.set_caption('RL-Snake')  #Überschrift der grafischen Oberfläche
        self.clock = pygame.time.Clock()    #.clock gibt die Zeit zurück, die Vergangen ist,
        #seitdem die Funktion zuletzt aufgerufen wurde.
        self.reset()    #reset Funktion wird aufgerufen


    def reset(self):
        # init game state
        self.direction = Direction.RIGHT

        self.head = Point(self.w/2, self.h/2)   # die Snake startet wieder in der Mitte des Spiels
        self.snake = [self.head]    # liste erstellen

        self.score = 0              # Punktestand wir auf 0 gesetzt
        self.food = None            # Am Anfang gibt es keinen Apfel
        self._place_food()          # Apfel wird generiert
        self.frame_iteration = 0    #Hilfvariable, um unendliche Schleifen zu verhindern


    def _place_food(self):  #Apfel an neuer Position erstellen
        x = random.randint(0, (self.w-BLOCK_SIZE )//BLOCK_SIZE )*BLOCK_SIZE    #An einem Zufälligem Ort erstellen
        y = random.randint(0, (self.h-BLOCK_SIZE )//BLOCK_SIZE )*BLOCK_SIZE
        self.food = Point(x, y)     # Apfelposition abspeichern
        if self.food in self.snake: # Wenn der Apfel in der Snake erstellt werden würde, die Funktion noch einmal
            self._place_food()      # aufrufen, um einen neuen Apfel zu generieren

    def apfel_zu_datei(self): # Apfelkoordinaten abspeichern

        # Y-Koordinate
        file = open("apfel_y.txt", "a")  # Erstellen/öffnen eines Textfiles, "a" = append (hinzufügen)
        file.write(
        str(int(self.food.y)) + "\n")  # die Y Koordinate in die Datei schreiben und in die nächste Zeile wechseln
        file.close()  # die Datei wieder schließen

        # X-Koordinate
        file = open("apfel_x.txt", "a")
        file.write(str(int(self.food.x)) + "\n")
        file.close()

    def laenge_zu_datei(self):  # Längde der Snake abspeichern
        file=open("laenge.txt", "a")        # Textdatei öffnen
        file.write(str(len(self.snake)))    # Länge der Snake abspeichern
        file.close()                        #Datei wieder schließen

    def play_step(self, action):    # Schritt machen
        self.frame_iteration += 1   # Hilfsvariable, um unendliche Schleifen zu verhindern

        self.apfel_zu_datei()       # Koordinaten des Apfels abspeichern
        self.laenge_zu_datei()      # Länge der Snake abspeichern
        # action: [gerade, rechts, links], 1 für die nächste Richtung. Nur ein Wert kann 1 sein, rest 0

        # 1. collect user input
        for event in pygame.event.get():    # Alle Events von PyGame durchgehen
            if event.type == pygame.QUIT:   # Wenn der Eventtyp "Quit" auftritt
                pygame.quit()               # uninitialisiert alle PyGame Prozesse
                quit()                      # beendet das python Program

        # 2. move
        self._move(action)              # die neue Bewegung der Snake anfordern
        self.snake.insert(0, self.head) # neue Kopfposition an der 1. Stelle der Liste platzieren

        # 3. check if game over
        reward = 0          # Belohnung ist 0
        game_over = False   # Spiel noch nicht vorbei
        if self.is_collision() or self.frame_iteration > 100*len(self.snake):   # Wenn die Snake gegen die Wand fährt
            # oder sie sich 100 * der Länge der Snake bewegt hat (z.B. Sie bewegt sich nur im Kreis)
            # len(self.snake) bei der Länge 0 beträgt 2. Bei der Länge 1, 3. -> Bei der Länge 0 darf die Snake 200 Schritte machen, ohne einen Apfel einzusammeln
            game_over = True    # das Spiel wird beendet
            reward = -10        # Die Snake ist gestorben, eine Negative Belohnung erfolgt

            return reward, game_over, self.score

        # 4. place new food or just move
        if self.head == self.food:  # Wenn die Snake den Apfel einsammelt
            self.score += 1         # Score um 1 erhöhen
            reward = 10             # die KI wird belohnt
            self._place_food()      #ein neuer Apfel wird platziert
        else:
            self.snake.pop()        # löscht ein Element einer Liste, wenn nichts übergeben wird, wird das letzte
                                    # Element entfernt (snake bleibt gleich, bewegt sich weiter)

        # 5. update ui and clock
        self._update_ui()       # grafische Oberfläche wird aktualisiert
        self.clock.tick(SPEED)  # Spielgeschwindigkeit initialisieren

        # 6. return game over and score
        return reward, game_over, self.score    #reward, score und ob das Spiel vorbei ist, wird zurückgegeben


    def is_collision(self, pt=None):   # Kollisionsabfrage
        if pt is None:      # pt ist eine Hilfsvariable. Wenn diese keinen Wert hat, wird die aktuelle
            pt = self.head  # Position des Kopfes der Snake übergeben

        # Snake trifft die Grenze
        if pt.x > self.w - BLOCK_SIZE or pt.x < 0 or pt.y > self.h - BLOCK_SIZE or pt.y < 0:
            return True # Ja, die Snake ist kollidiert

        # Snake stoßt gegen den eigenen Körper
        if pt in self.snake[1:]:    # Überprüft, ob der Kopf in den Körper der Snake fährt
                                    # geht die ganze Liste ab dem 2. Index durch und überprüft, ob der
                                    # Kopf = dem Körper ist
            return True # Ja, die Snake ist kollidiert

        return False    # Nein, die Snake ist nicht kollidiert


    def _update_ui(self):   # Grafische Oberfläche aktualisieren
        self.display.fill(BLACK)        # Hintergrundfarbe einstellen

        for pt in self.snake:           # die ganze Snake zeichnen
            pygame.draw.rect(self.display, BLUE1, pygame.Rect(pt.x, pt.y, BLOCK_SIZE, BLOCK_SIZE))  # 1. Rechteck zeichenn
            pygame.draw.rect(self.display, BLUE2, pygame.Rect(pt.x+4, pt.y+4, 12, 12))              # 2., etwas kleineres Rechteck zeichnen

        # den Kopf mit einer anderen Farbe zeichnen
        pygame.draw.rect(self.display, GREEN1, pygame.Rect(self.head.x, self.head.y, BLOCK_SIZE, BLOCK_SIZE))   # 1. Rechteck zeichnen
        pygame.draw.rect(self.display, GREEN2, pygame.Rect(self.head.x+4, self.head.y+4, 12, 12))               # 2., etwas kleineres Rechteck zeichnen

        # den Apfel zeichnen
        pygame.draw.rect(self.display, RED, pygame.Rect(self.food.x, self.food.y, BLOCK_SIZE, BLOCK_SIZE))

        # den aktuellen Score auf dem Bildschirm aktualisieren und zeichnen
        text = font.render("Score: " + str(self.score), True, WHITE)
        self.display.blit(text, [0, 0]) # oben Links in der Ecke zeichnen
        pygame.display.flip()           # den ganzen Bildschirm aktualisieren


    def _move(self, action):    # bewegung der Snake
        # action: [straight, right, left]

        clock_wise = [Direction.RIGHT, Direction.DOWN, Direction.LEFT, Direction.UP]    # Liste für die Richtung erstellen, Richtungen aus dem Direction Enum
        idx = clock_wise.index(self.direction)  # index in einer variable abspeichern

        if np.array_equal(action, [1, 0, 0]):   # Neue Richtung ist gerade
            new_dir = clock_wise[idx]           # Keine Veränderung
        elif np.array_equal(action, [0, 1, 0]): # Neue Richtung ist nach rechts
            next_idx = (idx + 1) % 4            # Neuer Index um 1 erhöhen, Modulo 4 damit es beim erreichen von 4 wieder auf 0 gesetzt wird
            new_dir = clock_wise[next_idx]      # Rechte Richtung right -> down -> left -> up, im Uhrzeigersinn
        else: # [0, 0, 1], Richtung nach links
            next_idx = (idx - 1) % 4
            new_dir = clock_wise[next_idx]      # Linke Richtung right -> up -> left -> down

        self.direction = new_dir                # Richtung in einer Variable speichern

        x = self.head.x                         # X-Koordinate des Kopfes der Snake
        y = self.head.y                         # Y-Koordinate des Kopfes der Snake

        if self.direction == Direction.RIGHT:   # Richtung nach rechts
            x += BLOCK_SIZE                     # X-Koordinate wird erhöht
        elif self.direction == Direction.LEFT:  # Richtung nach links
            x -= BLOCK_SIZE                     # X-Koordinate wird verkleinert
        elif self.direction == Direction.DOWN:  # Richtung nach unten
            y += BLOCK_SIZE                     # Y-Koordinate wird erhöht
        elif self.direction == Direction.UP:    # Richtung nach oben
            y -= BLOCK_SIZE                     # Y-Koordinate wird ehöht

        self.head = Point(x, y)                 # der Variable head die X und Y Koordinate mithilfe des namedtuples übergeben