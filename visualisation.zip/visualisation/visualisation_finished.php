<!DOCTYPE html>

<html>

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-colors-win8.css">
<title>Snake AI</title>

<style type="text/css">
.auto-style1 {
	margin-bottom: 2px;
}
.splitscreen {
    display:flex;
	justify-content: space-around;
	
}
.splitscreen .left {
	align-content: space-between;
	margin: 10px;
    flex: center;
}
.splitscreen .right {
	align-content: space-between;
	margin: 10px;
    flex: center;
}clear:both
}
</style>
</head>


<body class="w3-win8-steel">

<header class="w3-container w3-border-bottom w3-center w3-padding-32"> 
  <h1><b>Reinforcement Learning vs. Genetic Algorithmus</b></h1>
  <p>Diplomarbeit von Jonas Konzett und Noah Mangeng </p>
</header>

<div class="splitscreen">	<!-- 2 Leinwände (canvas) nebeneinander erstellen-->
    <div class="left">
       <canvas id="RL_canvas" width="640" height="480" style="border:2px solid #110110;"></canvas>
    </div>

    <div class="right">
        <canvas id="GA_canvas" width="640" height="480" style="border:2px solid #000000;"></canvas> 
    </div>
</div>

			



<?php
// Datei öffnen zum lesen und schreiben
$handle = fopen ("apfel_y.txt", "r");	//Textdatei öffen
$apfel_y = [];							//Array erstellen

while ( !feof($handle))					//solange das Ende der Datei noch nicht erreicht ist
{
  $apfel_y[] = fgets($handle);			//Daten in das Array schreiben

}
fclose($handle);						//Datei schließen
?>
<?php
// Datei öffnen zum lesen und schreiben
$handle = fopen ("apfel_x.txt", "r");
$apfel_x = [];
while ( !feof($handle))
{
  $apfel_x[] = fgets($handle);
  
}
?>

<?php
// Datei öffnen zum lesen und schreiben
$handle = fopen ("head_y.txt", "r");
$head_y = [];
while ( !feof($handle))
{
  $head_y[] = fgets($handle);
  
}
fclose($handle);
?>
<?php
// Datei öffnen zum lesen und schreiben
$handle = fopen ("head_x.txt", "r");
$head_x = [];
while ( !feof($handle))
{
  $head_x[] = fgets($handle);
  
}
fclose($handle);
?>

<?php
// Datei öffnen zum lesen und schreiben
$handle = fopen ("laenge.txt", "r");
$leange_snake = [];
while ( !feof($handle))
{
  $laenge_snake[] = fgets($handle);
  
}
fclose($handle);
?>




<?php
// Datei öffnen zum lesen und schreiben
$handle = fopen ("length.txt", "r");
$length = [];
while ( !feof($handle))
{
  $length[] = fgets($handle);
  
}
fclose($handle);
?>

<?php
// Datei öffnen zum lesen und schreiben
$handle = fopen ("applex.txt", "r");
$applex = [];
while ( !feof($handle))
{
  $applex[] = fgets($handle);
  
}
fclose($handle);
?>

<?php
// Datei öffnen zum lesen und schreiben
$handle = fopen ("appley.txt", "r");
$appley = [];
while ( !feof($handle))
{
  $appley[] = fgets($handle);
  
}
fclose($handle);
?>
<?php
// Datei öffnen zum lesen und schreiben
$handle = fopen ("snake_bodx.txt", "r");
$snake_bodx = [];
while ( !feof($handle))
{
  $snake_bodx[] = fgets($handle);
  
}
fclose($handle);
?>
<?php
// Datei öffnen zum lesen und schreiben
$handle = fopen ("snake_body.txt", "r");
$snake_body = [];
while ( !feof($handle))
{
  $snake_body[] = fgets($handle);
  
}
fclose($handle);
?>



<script>	
 
var c = document.getElementById("RL_canvas");	//canvas benennen
var ctx = c.getContext("2d");					//Inhalt des Canvas erhalten
ctx.fillStyle = "green";	//Hintergrundsfarbe des Canvas
ctx.fillRect(0, 0, RL_canvas.width, RL_canvas.height); //den Gesamten Canvas füllen
ctx.stroke();

var c = document.getElementById("GA_canvas");	//canvas benennen
var ctx = c.getContext("2d");					//Inhalt des Canvas erhalten
ctx.fillStyle = "green";	//Hintergrundsfarbe des Canvas
ctx.fillRect(0, 0, GA_canvas.width, GA_canvas.height); //den Gesamten Canvas füllen
ctx.stroke();

//Die X und Y Koordinaten des Apfels und Kopfes sowie die Länge der Snake werden ausgelesen und in verschiedenen Arrays gespeichert.
//mithilfe der json_encode funktion können php Daten in ein js array abgespeichert werden.

	var apfel_y = <?php echo json_encode($apfel_y); ?>;	// Y-Koordinate des Apfels

	var apfel_x = <?php echo json_encode($apfel_x); ?>;	// X-Koordinate des Apfels
	
	var head_y = <?php echo json_encode($head_y); ?>;	// Y-Koordinate des Kopfes

	var head_x = <?php echo json_encode($head_x); ?>;	// X-Koordinate des Kopfes
	
	var laenge_schlange = <?php echo json_encode($laenge_snake); ?>;	// Länge der Snake

	var head_count = Object.keys(head_y).length;		// Länge der Kopfdatei -> gesamte Anzahl an Schritten
	
	// Dasselbe für den GA einlesen
	var applex = <?php echo json_encode($applex); ?>;	// x-Koordinate des Apfels

	var appley = <?php echo json_encode($appley); ?>;	// y-Koordinate des Apfels
	
	var snake_bodx = <?php echo json_encode($snake_bodx); ?>;	// x-Koordinate des Kopfes

	var snake_body = <?php echo json_encode($snake_body); ?>;	// y-Koordinate des Kopfes
	
	var length = <?php echo json_encode($length); ?>;	// Länge der Snake

	var number_of_steps = Object.keys(length).length;	// gesamte Anzahl an Schritten
	// Sollte mit der variable head_count übereinstimmen, damit beide Simulationen zur selben zeit beendet werden
	
	
	//Zeichnet die Snake
	function snake_zeichnen(laenge_schlange, head_x, head_y, i, canvas_name)
	{	 
		
		// Angegebenen Canvas auswählen
		var c = document.getElementById(canvas_name);	
		var ctx = c.getContext("2d");
											
		// Körper durchlaufen
		for(k = 0; k <= laenge_schlange[i]-1; k++)
		{	
			// Umrandung für die Snake
			ctx.fillStyle = "black";
			ctx.fillRect(head_x[i- k]-1, head_y[i- k]-1, 22, 22);
			
			// Körper der Snake zeichnen
			ctx.fillStyle = "blue";		
			ctx.fillRect(head_x[i- k], head_y[i- k], 20, 20);
			
			
		}
		
		//Farbe des Kopfes der Snake
		ctx.fillStyle = "cyan";		
			
		//Kopf zeichnen
		ctx.fillRect(head_x[i], head_y[i], 20, 20);	
		
	}
	
	
	// Das Ende der Snake für jeden Schritt löschen
	function canvas_loeschen(requested_canvas, canvas_name)
	{	
		// Angegebenen Canvas auswählen
		var c = document.getElementById(canvas_name);	
		var ctx = c.getContext("2d");
		
		//Farbe auf grün setzten (Hintergrundfarbe)
		ctx.fillStyle = "green";							
	
		// Canvas löschen
		ctx.fillRect(0,0, requested_canvas.width, requested_canvas.height);	
	}
	
	
	// Für jeden Schritt den Apfel zeichnen
	function apfel_zeichnen(apfel_x, apfel_y,i,canvas_name)
	{	
		// Angegebenen Canvas auswählen
		var c = document.getElementById(canvas_name);	
		var ctx = c.getContext("2d");
		
		// Farbe Rot
		ctx.fillStyle="red";			
		
		// Apfel mit der Größe 20x20 an den Koordinaten des Apfels zeichnen
		ctx.fillRect(apfel_x[i],apfel_y[i],20,20);	
	}
	
	

	// Punktestand auf den Canvas schreiben
	function draw_score(laenge_schlange, i, canvas_name)
	{ 
		// Angegebenen Canvas auswählen
		var c = document.getElementById(canvas_name);	// Canvas benennen
		var ctx = c.getContext("2d");
		
		// Schriftfarbe Schwarz
		ctx.fillStyle="black";	

		// Schriftgröße
		ctx.font = "30px Arial";	
		
		// Score: + Länge der Snake ausgeben
		ctx.fillText("Score:", 5, 30)
		// -1 da die Snake mit der Länge 1 startet
		ctx.fillText(laenge_schlange[i]-1, 93, 30);	
	}
	
	
// Zusammenführung aller Funktionen
function start(i)
{		
  // Delay erstellen, um die Geschwindigkeit der Snake zu drosseln
  setTimeout(function timer() 
  {			
  
						
	canvas_loeschen(RL_canvas, "RL_canvas");			// Canvas für das RL "löschen"
	
	canvas_loeschen(GA_canvas, "GA_canvas");			// Canvas für den GA "löschen"
	
	apfel_zeichnen(apfel_x, apfel_y,i, "RL_canvas");	// Der Apfel des RL zeichnen
	
	apfel_zeichnen(applex, appley, i, "GA_canvas");		// Der Apfel des GA zeichnen
	
    snake_zeichnen(laenge_schlange, head_x, head_y, i, "RL_canvas");	// RL Snake zeichnen
	
	snake_zeichnen(length, snake_bodx, snake_body, i, "GA_canvas");		// GA Snake zeichnen
	
	draw_score(laenge_schlange, i, "RL_canvas");		// Score des RL schreiben
		
	draw_score(length, i, "GA_canvas");					// Score des GA schreiben
	

		
  }, i*10);	//Delay von 100ms
}

  // Für jeden Schritt der Snake die function start(i) ausführen
  for (let i = 0; i < head_count-1; i ++) 
  {	
  	
	start(i);
  }
  

</script>	

</body>
</html>



